<?php

class Application_Model_DbTable_Prato extends Zend_Db_Table_Abstract
{
    protected $_name = 'prato';
    protected $_primary = 'idprato';
}

