<?php

class Application_Model_Vo_Categoria {
    private $idcategoria;
    private $nomecategoria;
    
    function getIdcategoria() {
        return $this->idcategoria;
    }

    function getNomecategoria() {
        return $this->nomecategoria;
    }

    function setIdcategoria($idcategoria) {
        $this->idcategoria = $idcategoria;
    }

    function setNomecategoria($nomecategoria) {
        $this->nomecategoria = $nomecategoria;
    }

}