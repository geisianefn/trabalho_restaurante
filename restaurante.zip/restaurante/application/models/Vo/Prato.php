<?php

class Application_Model_Vo_Prato {

    private $idprato;
    private $idcategoria;
    private $idusuario;
    private $nome;
    private $descricao;
    private $preco;

    function getIdprato() {
        return $this->idprato;
    }

    function getIdcategoria() {
        return $this->idcategoria;
    }

    function getIdusuario() {
        return $this->idusuario;
    }

    function getNome() {
        return $this->nome;
    }

    function getDescricao() {
        return $this->descricao;
    }

    function getPreco() {
        return $this->preco;
    }

    function setIdprato($idprato) {
        $this->idprato = $idprato;
    }

    function setIdcategoria($idcategoria) {
        $this->idcategoria = $idcategoria;
    }

    function setIdusuario($idusuario) {
        $this->idusuario = $idusuario;
    }

    function setNome($nome) {
        $this->nome = $nome;
    }

    function setDescricao($descricao) {
        $this->descricao = $descricao;
    }

    function setPreco($preco) {
        $this->preco = $preco;
    }

}
