<?php

class Application_Model_Usuario {

    public function apagar($idcategoria) {
        throw new Application_Model_Exception('O usuário não pode ser apagado do sistema');
    }

    public function atualizar(Application_Model_Vo_Usuario $usuario) {
        $tb = new Application_Model_DbTable_Usuario();

        $tb->update(array(
            'nome' => $usuario ->getNome(),
            'email' => $usuario ->getEmail(),
            'senha' => $usuario ->getSenha(),
            'perfil' => $usuario ->getPerfil(),
                ), 'idusuario = ' . $usuario ->getIdusuario());
    }

    public function salvar(Application_Model_Vo_Usuario $usuario) {
        $tb = new Application_Model_DbTable_Usuario();

        $tb->insert(array(
            'nome' => $usuario ->getNome(),
            'email' => $usuario ->getEmail(),
            'senha' => $usuario ->getSenha(),
            'perfil' => $usuario ->getPerfil(),
        ));

        $usuario ->setIdusuario($tb ->getAdapter() ->lastInsertId());
    }

}
