<?php

class Application_Model_User
{


}

