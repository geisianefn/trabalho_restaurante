<?php

class Application_Model_Categoria {

    public function apagar($idcategoria) {

        $tabprato = new Application_Model_DbTable_Prato();
        $prato = $tabprato ->fetchRow("idcategoria = $idcategoria");  

        if($prato !== null)  
        {
            throw new Exception("Categoria com Prato", 1);   
            
        }

        $tab = new Application_Model_DbTable_Categoria();
        $tab ->delete("idcategoria = $idcategoria");   

        return true;
        
    }

    public function atualizar(Application_Model_Vo_Categoria $nomecategoria) {

        $tab = new Application_Model_DbTable_Categoria();   
        $tab ->update(array('nome_categoria' => $nomecategoria ->getNomecategoria()    
            ), 'idcategoria = ' . $nomecategoria ->getIdcategoria());         
        
    }

    public function salvar(Application_Model_Vo_Categoria $nomecategoria) {

    	$tab = new Application_Model_DbTable_Categoria();
    	$tab ->insert(array(   
    		  'nome_categoria' => $nomecategoria ->getNomecategoria()   

    		));

    	$id = $tab ->getAdapter() ->lastInsertId();  
    	$nomecategoria ->setIdcategoria($id);   

    	return true;
        
    }

}
