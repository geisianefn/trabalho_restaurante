<?php

class Application_Form_Usuario extends Zend_Form {

    private $emailNaoRepetidoVal;

    public function init() {
        $this->setMethod('post');

        $idusuario = new Zend_Form_Element_Hidden('idusuario');
        $this->addElement($idusuario);
        
        $nome = new Zend_Form_Element_Text('nome', array(
            'label' => 'Nome completo',
            'required' => true,
        ));
        $this->addElement($nome);

        $this->emailNaoRepetidoVal = new Zend_Validate_Db_NoRecordExists(array(
            'table' => 'usuario',
            'field' => 'email'
        ));

        $email = new Zend_Form_Element_Text('email', array(
            'label' => 'Endereço de email',
            'required' => true,
        ));
        $email->addValidator(new Zend_Validate_EmailAddress());
        $email->addValidator($this->emailNaoRepetidoVal);
        $this->addElement($email);
        
        $senha = new Zend_Form_Element_Password('senha', array(
            'label' => 'Senha',
            'required' => true,
        ));
        $this->addElement($senha);
        
        $perfil = new Zend_Form_Element_Select('perfil', array(
            'label' => 'Perfil',
            'required' => true,
        ));
        $perfil->setMultiOptions(array(
            1 => 'Gerente',
            2 => 'Cozinheiro'
        ));
        $this->addElement($perfil);

        $submit = new Zend_Form_Element_Submit('submit', array(
            'label' => 'Salvar'
        ));
        $this->addElement($submit);
    }

    function setIdusuario($idusuario) {
        $this->emailNaoRepetidoVal->setExclude('idusuario != ' . $idusuario);
    }

}
