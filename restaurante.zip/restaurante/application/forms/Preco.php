<?php

class Application_Form_Preco extends Zend_Form {

    public function init() {
        $this->setMethod('post');

        $val = new Zend_Validate_StringLength();    
        $val ->setMin(5);  

        $nome = new Zend_Form_Element_Text('nome', array(   
        		'label' => 'Nome do prato',
        		'required' => true  
        	));

        $nome ->addValidator($val);      

        $this ->addElement($nome);

        $categoria = new Zend_Form_Element_Select('idcategoria', array(
        		'label' => 'Categoria',
        		'required' => true 
        	));

        $this ->addElement($categoria);     
   
        $categoria ->setMultiOptions($this ->pegarCategorias());  

        $f = new Zend_Filter_Null();  
        $categoria ->addFilter($f);  

        $preco = new Zend_Form_Element_Text('preco', array(
            'label' => 'Preço do prato'

           ));  


        $filtro = new Zend_Filter_Null();  
        $preco ->addFilter($filtro); 

        $this ->addElement($preco);   

        $botao = new Zend_Form_Element_Submit('botao', array(   
                'label' => 'Salvar'
            ));

         $this ->addElement($botao); 
    }

    public function pegarCategorias() {

    	$tab = new Application_Model_DbTable_Categoria();   

        $categorias = $tab ->fetchAll() ->toArray();   

        $options = array();
        $options[0] = 'Selecione uma Categoria';
        foreach ($categorias as $item)  
        {
        	$idcategoria = $item['idcategoria'];   
        	$nomeCategoria = $item['nome_categoria'];  

        	$options[$idcategoria] = $nomeCategoria;  
        }

        return $options;
    }

}
