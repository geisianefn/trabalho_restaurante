<?php

class PratoController extends Restaurante_Controller_Action {

    public function indexAction() {

      $tab = new Application_Model_DbTable_Prato();
       $consulta = $tab->getAdapter()->select();
       $consulta->from(array(
           "p"=>"prato"
       ), array(
           "idprato", "nome"
       ));

       $consulta->joinInner(array(
           "c"=>"categoria"
       ), "c.idcategoria = p.idcategoria", array(
           "nome_categoria"
       ));

       $consulta->where("p.idcategoria > ?", "0", Zend_Db::INT_TYPE);
      
       $consultaBd = $consulta ->query() ->fetchAll();
       $this ->view ->pratos = $consultaBd;
       $this ->view ->podePreco = $this ->aclIsAllowed('prato', 'preco');
       $this ->view ->podeApagar = $this ->aclIsAllowed('prato', 'delete');
        
    }

    public function createAction() {

        $frm = new Application_Form_Prato();   

        if($this ->getRequest() ->isPost())
        {
            $params = $this ->getAllParams();

            if($frm ->isValid($params))
            {
                
                $auth = Zend_Auth::getInstance();

                $params = $frm ->getValues();  

                $prato = new Application_Model_Vo_Prato();
                $prato ->setIdcategoria($params['idcategoria']);  
                $prato ->setIdusuario($auth ->getIdentity() ->idusuario);
                $prato ->setNome($params['nome']);
                $prato ->setDescricao($params['descricao']);

                $model = new Application_Model_Prato();  
                $model ->salvar($prato);    

                $flashMessenger = $this ->_helper ->FlashMessenger;  
                $flashMessenger ->addMessage("Prato salvo!");   

                $this ->_helper ->Redirector ->gotoSimpleAndExit('index'); 
            }
        }

        $this ->view ->frm = $frm;   
        
    }

    public function deleteAction() {

    	$idprato = (int) $this ->getParam('idprato', 0);  

        $model = new Application_Model_Prato();   
        $model ->apagar($idprato);   

        $flashMessenger = $this ->_helper ->FlashMessenger;   
        $flashMessenger ->addMessage("Registro apagado");     

        $this ->_helper ->Redirector ->gotoSimpleAndExit('index');
        
    }

    public function updateAction() {

    $idprato = (int) $this ->getParam('idprato', 0);  
    
    $tabela = new Application_Model_DbTable_Prato();   
    $linha = $tabela ->fetchRow('idprato = ' . $idprato);  

    if($linha === null)  
    {
        echo 'Prato inexistente';
        exit;
    } 

    $frm = new Application_Form_Prato();  

        if($this ->getRequest() ->isPost())  
        {
            $params = $this ->getAllParams();    

            if($frm ->isValid($params))
            {
                $auth = Zend_Auth::getInstance();

                $params = $frm ->getValues();   

                $prato = new Application_Model_Vo_Prato();
                $prato ->setIdcategoria($params['idcategoria']);
                $prato ->setIdusuario($auth ->getIdentity() ->idusuario);
                $prato ->setNome($params['nome']);
                $prato ->setDescricao($params['descricao']);
                $prato ->setIdprato($idprato);

                $model = new Application_Model_Prato();  
                $model ->atualizar($prato);    

                $flashMessenger = $this ->_helper ->FlashMessenger;  
                $flashMessenger ->addMessage("Prato salvo!");   

                $this ->_helper ->Redirector ->gotoSimpleAndExit('index');   
            }        
        
    } else {   

         $frm ->populate(array(    

            'idcategoria' => $linha ->idcategoria,
            'idusuario' => $linha ->idusuario,
            'nome' => $linha ->nome,
            'descricao' => $linha ->descricao

            ));    
    }

    $this ->view ->frm = $frm;
        
 }

  public function precoAction() {

    $idprato = (int) $this ->getParam('idprato', 0);  
    
    $tabela = new Application_Model_DbTable_Prato();   
    $linha = $tabela ->fetchRow('idprato = ' . $idprato);  

    if($linha === null)  
    {
        echo 'Prato inexistente';
        exit;
    } 

    $frm = new Application_Form_Preco();  

        if($this ->getRequest() ->isPost())  
        {
            $params = $this ->getAllParams();    

            if($frm ->isValid($params))
            {
                
                $auth = Zend_Auth::getInstance();

                $params = $frm ->getValues();   

                $prato = new Application_Model_Vo_Prato();
                $prato ->setIdcategoria($params['idcategoria']);
                $prato ->setIdusuario($auth ->getIdentity() ->idusuario);
                $prato ->setNome($params['nome']);
                $prato ->setDescricao($params['descricao']);
                $prato ->setPreco($params['preco']);
                $prato ->setIdprato($idprato);

                $model = new Application_Model_Prato();  
                $model ->atualizarPreco($prato);    

                $flashMessenger = $this ->_helper ->FlashMessenger;  
                $flashMessenger ->addMessage("Prato salvo!");   

                $this ->_helper ->Redirector ->gotoSimpleAndExit('index', 'prato');   
            }        
        
    } else {   

         $frm ->populate(array(    

            'idcategoria' => $linha ->idcategoria,
            'idusuario' => $linha ->idusuario,
            'nome' => $linha ->nome,
            'descricao' => $linha ->descricao,
            'preco' => $linha ->preco

            ));    
    }

    $this ->view ->frm = $frm;
        
    }


}
